angular.module('dashboardRouter', ['ngRoute'])
.config(['$routeProvider', function($routeProvider) {
            $routeProvider.
            
            when('/', {
               templateUrl: 'application/landingPage/landingPage.html',
               controller: 'landingController',
               
            })
 }]);