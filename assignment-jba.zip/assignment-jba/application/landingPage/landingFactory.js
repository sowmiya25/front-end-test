app.factory('landingFactory', ['$http', '$q',
	function ($http, $q) {
		return {
			getData : function (url) {
				var deferred = $q.defer();
				$http.get(url)
				.then(function(response) {
					deferred.resolve(response.data);										
				},
				function(error) {
					deferred.reject(error);
				});
				return deferred.promise;
			}
		}
	}
]);