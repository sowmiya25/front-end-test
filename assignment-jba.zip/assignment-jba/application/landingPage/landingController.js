app.controller('landingController', [ '$scope','landingFactory',
	function ($scope,landingFactory) {
		/*setting Graph Options*/
		$scope.options = {
                chart: {
                type: 'lineChart',
                height: 450,
                margin : {
                    top: 20,
                    right: 20,
                    bottom: 40,
                    left: 55
                },
                x: function(d){return d.label;},
                y: function(d){return d.value;},
                useInteractiveGuideline: true,
			    lines: {
			        forceX: 300,
			        forceY: 25000
			    }
            }
        }

        /*Getting server List*/
		landingFactory.getData('https://jbanew.staging.joybusinessacademy.com/api/v2/assignment/servers').then(function (response) {
			$scope.serverList = response.source.rows;
		});
		
		
		/*Gettin server data list*/
		$scope.getGraph = function(id,index){	
			$scope.selected = index;		
			landingFactory.getData('https://jbanew.staging.joybusinessacademy.com/api/v2/assignment/servers/'+id).then(function (response) {
			$scope.items = response.source.data.value;	
			$scope.low = Math.min.apply(Math, $scope.items);
			$scope.high = Math.max.apply(Math, $scope.items);
			$scope.sum =  $scope.items
		    .map( function(elt){ 
		      return /^\d+$/.test(elt) ? parseInt(elt) : 0; 
		    })
		    .reduce( function(a,b){
		      return a+b
		    })
		    $scope.avg = $scope.sum/$scope.items.length;
			$scope.data = $scope.setgraphData();
	        $scope.$applyAsync;
			});
		}

		/*constructing graph struture*/
		$scope.setgraphData = function(){
			var data=[];
			data.push({
                key: 'Graph',
                values: []
            });
			for (var i = 0; i < $scope.items.length; i++) {
                data[0].values.push({
                   label: i,
                   value: $scope.items[i]	
                });
            }
            return data
		}

		/*Initial graph load*/
		$scope.getGraph(5,0);
		
	}
]);