var app = angular.module('dashboardApp', ['dashboardRouter', 'nvd3']);
